import React from "react";

const Footer = () => {
  return (
    <div>
      <p>
        "Add - Unit No -3, H 272 Bharat Tower, Palam Vihar, Near Krishna Chowk,
        Gurugram -122017 "
      </p>

      <p> Contact: 7011724492 </p>
    </div>
  );
};

export default Footer;
