import React from 'react'

const Cell = () => {
  return (
    <div>
      <h1>hui</h1>
    </div>
  )
}

export default Cell
