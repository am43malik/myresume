
import './App.css';
import Footer from './components/Footer';
import Main from './components/Main';
import PdfDownload from './components/PdfDownload';
import Tex from './components/Tex';
import Uploadcv from './components/Uploadcv';
// import Uploadcv from './components/Uploadcv';

function App() {
  return (
    <div className="App">
      {/* <Tex/> */}
     <Main/>
      {/* <Pdf/> */}
      {/* <Uploadcv/> */}
     <Footer/>
    </div>
  );
}

export default App;
